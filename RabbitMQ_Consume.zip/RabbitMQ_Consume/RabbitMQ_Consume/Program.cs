﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;

var factory = new ConnectionFactory()
{
    HostName = "localhost",
};

await using var connection = await factory.CreateConnectionAsync();
await using var channel = await connection.CreateChannelAsync();


var consumer = new AsyncEventingBasicConsumer(channel);

consumer.ReceivedAsync += async (m, args) =>
{
    var body = args.Body.ToArray();
    string message = Encoding.UTF8.GetString(body);
};

await channel.BasicConsumeAsync(queue: "Test_Queue", autoAck: true, consumer: consumer);
Console.WriteLine("Messages Consumed");

Console.ReadLine();



