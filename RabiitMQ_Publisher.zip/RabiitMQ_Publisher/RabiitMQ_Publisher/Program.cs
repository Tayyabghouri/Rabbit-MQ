﻿using RabbitMQ.Client;
using System.Text;

var facotry = new ConnectionFactory()
{
    HostName = "localhost",
};

await using var connection = await facotry.CreateConnectionAsync();

await using var channel = await connection.CreateChannelAsync();

string message = "This is just a test message";

var bodyMessage = Encoding.UTF8.GetBytes(message);

var props = new BasicProperties();

await channel.BasicPublishAsync(
    exchange: "",
    routingKey: "Test_Queue",
    mandatory: false,
    basicProperties: props,
    body: new ReadOnlyMemory<byte>(bodyMessage)
);


Console.WriteLine("Message has been sent!");
Console.ReadLine();

//for fanout wee need to create exchange and also consumers and then use here in case of fanout we don't need to d routing key but exchange name